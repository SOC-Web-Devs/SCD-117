const createUser  = async (user) => {
  await axios
      .post('http://localhost:4000/api/agents/agent', user)
      .then(response => {
        const addedUser = response.data
        console.log(`POST: user is added`, addedUser)
        // append to DOM
        //appendToDOM([addedUser])
        const matrixUser = {
            child_id: addedUser.id,
            parent_id: addedUser.referral_id,
            left_child : null,
            right_child : null
        }
      createUserMatrix(matrixUser)
      })
      .catch(error => console.error(error))  
  }


const createUserMatrix  = async (user) => {
  await axios
      .post('http://localhost:4000/api/agents/matrix', user)
      .then(response => {
        const addedUser = response.data
        console.log(`POST: user is added`, addedUser)
        // append to DOM
        //appendToDOM([addedUser])
      })
      .catch(error => console.error(error))  
  }

